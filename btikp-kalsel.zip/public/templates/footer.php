<?php
/**
 * Public Footer Template
 */

// 1. Load OfficeHours Class
// Pastikan path ini sesuai dengan struktur folder Anda. 
if (file_exists(__DIR__ . '/../../core/OfficeHours.php')) {
    require_once __DIR__ . '/../../core/OfficeHours.php';
}

// 2. Init Office Hours & Get Status
$office = new OfficeHours();
$officeStatus = $office->getStatus();
$workingHoursText = $office->getFormattedWorkingHours();

// Mapping warna Tailwind berdasarkan status
// Default values
$statusColor = 'bg-gray-600';
$statusIcon = 'fa-door-closed';

if ($officeStatus) {
    // Kita override variable local berdasarkan return dari Class
    // (Meskipun Class OfficeHours di atas sudah return 'badge' class bootstrap/tailwind, 
    // kita mapping ulang disini untuk kepastian desain footer ini)
    switch ($officeStatus['status']) {
        case 'open':
            $statusColor = 'bg-green-600';
            $statusIcon = 'fa-door-open';
            break;
        case 'break':
            $statusColor = 'bg-yellow-600';
            $statusIcon = 'fa-mug-hot';
            break;
        case 'holiday':
            $statusColor = 'bg-red-600';
            $statusIcon = 'fa-calendar-times';
            break;
        default: // closed
            $statusColor = 'bg-gray-600';
            $statusIcon = 'fa-door-closed';
            break;
    }
}

// Get footer settings
$footer_about = getSetting('footer_about', 'Balai Teknologi Informasi dan Komunikasi Pendidikan Kalimantan Selatan');
$footer_address = getSetting('footer_address', 'Jl. A. Yani KM 36, Banjarmasin, Kalimantan Selatan');
$contact_email = getSetting('contact_email', 'info@btikpkalsel.id');
$contact_phone = getSetting('contact_phone', '(0511) 1234567');

// Get all social media links
$social_media = [
    'facebook' => ['url' => getSetting('social_facebook'), 'icon' => 'fab fa-facebook', 'name' => 'Facebook'],
    'twitter' => ['url' => getSetting('social_twitter'), 'icon' => 'fab fa-twitter', 'name' => 'Twitter'],
    'instagram' => ['url' => getSetting('social_instagram'), 'icon' => 'fab fa-instagram', 'name' => 'Instagram'],
    'youtube' => ['url' => getSetting('social_youtube'), 'icon' => 'fab fa-youtube', 'name' => 'YouTube'],
    'linkedin' => ['url' => getSetting('social_linkedin'), 'icon' => 'fab fa-linkedin', 'name' => 'LinkedIn'],
    'tiktok' => ['url' => getSetting('social_tiktok'), 'icon' => 'fab fa-tiktok', 'name' => 'TikTok'],
];

$active_socials = array_filter($social_media, function($social) {
    return !empty($social['url']);
});
?>
    </div>
    <footer class="bg-gray-900 text-white py-12">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                
                <div>
                    <h3 class="text-xl font-bold mb-4"><?= getSetting('site_name', 'BTIKP Kalsel') ?></h3>
                    <p class="text-gray-400 mb-4"><?= $footer_about ?></p>
                    
                    <?php if ($officeStatus): ?>
                    <div class="mb-6 inline-block animate-pulse">
                        <div class="flex items-center px-3 py-2 rounded-lg text-white text-sm font-medium shadow-lg <?= $statusColor ?>">
                            <i class="fas <?= $statusIcon ?> mr-2"></i>
                            <span>Kantor <?= $officeStatus['message'] ?></span>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($active_socials)): ?>
                    <div class="flex flex-wrap gap-2">
                        <?php foreach ($active_socials as $platform => $social): ?>
                        <a href="<?= htmlspecialchars($social['url']) ?>" 
                           target="_blank" 
                           rel="noopener" 
                           class="w-10 h-10 bg-gray-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition"
                           title="<?= $social['name'] ?>">
                            <i class="<?= $social['icon'] ?> text-lg"></i>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div>
                    <h3 class="text-xl font-bold mb-4">Menu Cepat</h3>
                    <ul class="space-y-2">
                        <li><a href="<?= BASE_URL ?>" class="text-gray-400 hover:text-white transition"><i class="fas fa-chevron-right mr-2 text-xs"></i>Beranda</a></li>
                        <li><a href="<?= BASE_URL ?>posts.php" class="text-gray-400 hover:text-white transition"><i class="fas fa-chevron-right mr-2 text-xs"></i>Berita</a></li>
                        <li><a href="<?= BASE_URL ?>gallery.php" class="text-gray-400 hover:text-white transition"><i class="fas fa-chevron-right mr-2 text-xs"></i>Galeri</a></li>
                        <li><a href="<?= BASE_URL ?>services.php" class="text-gray-400 hover:text-white transition"><i class="fas fa-chevron-right mr-2 text-xs"></i>Layanan</a></li>
                        <li><a href="<?= BASE_URL ?>files.php" class="text-gray-400 hover:text-white transition"><i class="fas fa-chevron-right mr-2 text-xs"></i>Unduhan</a></li>
                        <li><a href="<?= BASE_URL ?>contact.php" class="text-gray-400 hover:text-white transition"><i class="fas fa-chevron-right mr-2 text-xs"></i>Kontak</a></li>
                    </ul>
                </div>
                
                <div>
                    <h3 class="text-xl font-bold mb-4">Berita Terbaru</h3>
                    <ul class="space-y-3">
                        <?php
                        // Memanggil fungsi untuk mendapatkan 3 berita terbaru
                        if (function_exists('get_recent_posts')) {
                            $recent_posts = get_recent_posts(3);
                            foreach ($recent_posts as $post):
                        ?>
                        <li>
                            <a href="<?= BASE_URL ?>post.php?slug=<?= $post['slug'] ?>" class="text-gray-400 hover:text-white transition text-sm line-clamp-2">
                                <?= function_exists('truncateText') ? truncateText($post['title'], 100) : substr($post['title'], 0, 100) ?>
                            </a>
                            <div class="text-xs text-gray-500 mt-1">
                                <i class="far fa-calendar mr-1"></i><?= function_exists('formatTanggal') ? formatTanggal($post['created_at'], 'd M Y') : date('d M Y', strtotime($post['created_at'])) ?>
                            </div>
                        </li>
                        <?php 
                            endforeach; 
                        }
                        ?>
                    </ul>
                </div>
                
                <div>
                    <h3 class="text-xl font-bold mb-4">Kontak Kami</h3>
                    <ul class="space-y-3 text-gray-400">
                        <li class="flex items-start">
                            <i class="fas fa-map-marker-alt mt-1 mr-3 text-blue-400 flex-shrink-0"></i>
                            <span class="text-sm"><?= $footer_address ?></span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-envelope mr-3 text-blue-400 flex-shrink-0"></i>
                            <a href="mailto:<?= $contact_email ?>" class="text-sm hover:text-white transition break-all"><?= $contact_email ?></a>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-phone mr-3 text-blue-400 flex-shrink-0"></i>
                            <a href="tel:<?= str_replace(['(', ')', ' ', '-'], '', $contact_phone) ?>" class="text-sm hover:text-white transition"><?= $contact_phone ?></a>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-clock mt-1 mr-3 text-blue-400 flex-shrink-0"></i>
                            <span class="text-sm"><?= $workingHoursText ?></span>
                        </li>
                    </ul>
                </div>
                
            </div>
            
            <div class="mt-8 pt-8 border-t border-gray-800 text-center text-gray-400">
                <p>&copy; <?= date('Y') ?> <?= getSetting('site_name', 'BTIKP Kalimantan Selatan') ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <div id="searchModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-lg max-w-2xl w-full p-6">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-xl font-bold text-gray-900">Pencarian</h3>
                <button onclick="closeSearchModal()" class="text-gray-500 hover:text-gray-700">
                    <i class="fas fa-times text-2xl"></i>
                </button>
            </div>
            <form action="<?= BASE_URL ?>search.php" method="GET">
                <input type="text" name="q" placeholder="Cari berita, layanan, atau halaman..." 
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                       autofocus>
                <button type="submit" class="mt-4 w-full btn-primary">
                    <i class="fas fa-search mr-2"></i> Cari
                </button>
            </form>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    
    <script src="<?= BASE_URL ?>assets/js/custom.js?v=1.0"></script>
    
    <script>
        // Apply theme colors dynamically
        if (window.BTIKPKalsel && window.BTIKPKalsel.applyThemeColors) {
            BTIKPKalsel.applyThemeColors({
                primary: '<?= getSetting('public_theme_primary_color', '#667eea') ?>',
                secondary: '<?= getSetting('public_theme_secondary_color', '#764ba2') ?>',
                accent: '<?= getSetting('public_theme_accent_color', '#f093fb') ?>',
                text: '<?= getSetting('public_theme_text_color', '#333333') ?>',
                background: '<?= getSetting('public_theme_background_color', '#ffffff') ?>'
            });
        }

        // Simple Back to Top Logic
        const backToTopButton = document.createElement('button');
        backToTopButton.innerHTML = '<i class="fas fa-arrow-up"></i>';
        backToTopButton.className = 'fixed bottom-8 right-8 bg-blue-600 text-white w-12 h-12 rounded-full shadow-lg flex items-center justify-center transition transform hover:-translate-y-1 hidden z-40';
        document.body.appendChild(backToTopButton);

        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                backToTopButton.classList.remove('hidden');
            } else {
                backToTopButton.classList.add('hidden');
            }
        });

        backToTopButton.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    </script>
</body>
</html>